package com.dbxtest.merliandras;

import com.dbxtest.merliandras.exception.GameException;
import com.dbxtest.merliandras.model.GameInfo;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class GameInfoTest {
    @Test
    void testSuccessFulConstruction() {
        try {
            new GameInfo("t0");
        } catch (GameException e) {
            Assertions.fail("The construction of the obj should have been successful");
        }
    }

    @Test
    void testConstructionException() {
        Assertions.assertThrows(GameException.class, ()->new GameInfo("t"), "The input file is not found");
        Assertions.assertThrows(GameException.class, ()->new GameInfo("tempty"), "Not enough lines in the file");
        Assertions.assertThrows(GameException.class, ()->new GameInfo("tnoscoreind"), "Couldn't get the necessary 'score to win' parameter (last line in the file)");
        Assertions.assertThrows(GameException.class, ()->new GameInfo("tnotrect"), "The input 2D array doesn't have a rectangular shape!");
        Assertions.assertThrows(GameException.class, ()->new GameInfo("tinvchar"), "The game board contains the invalid character: 0");
    }
}
