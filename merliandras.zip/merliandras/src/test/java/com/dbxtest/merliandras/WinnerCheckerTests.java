package com.dbxtest.merliandras;

import com.dbxtest.merliandras.exception.GameException;
import com.dbxtest.merliandras.model.GameInfo;
import com.dbxtest.merliandras.model.Winner;
import com.dbxtest.merliandras.service.*;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

class WinnerCheckerTests {
	private final static Map<String, Winner> FILE_RESULTS = new HashMap<>(); //Map.of(
	private final static WinnerChecker winnerChecker = new WinnerChecker();

	static {
		FILE_RESULTS.put("t0", Winner.PLAYER_2_O);
		FILE_RESULTS.put("t1", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t2", Winner.PLAYER_2_O);
		FILE_RESULTS.put("t3", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t4", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t5", Winner.DRAW);
		FILE_RESULTS.put("t6", Winner.NO_WINNER_YET);
		FILE_RESULTS.put("t7", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t8", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t9", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t10", Winner.NO_WINNER_YET);
		FILE_RESULTS.put("t11", Winner.PLAYER_2_O);
		FILE_RESULTS.put("t12", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t13", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t14", Winner.PLAYER_2_O);
		FILE_RESULTS.put("t15", Winner.PLAYER_1_X);
		FILE_RESULTS.put("t16", Winner.PLAYER_2_O);
		FILE_RESULTS.put("t17", Winner.DRAW);
	}

	@Test
	void testGetWinner() {
		winnerChecker.setWinCheckerStrategies(Arrays.asList(
				new RowWinChecker(), new ColumnWinChecker(), new DiagonalWinChecker(), new AntiDiagonalWinChecker()));
		try {
			for (Map.Entry<String, Winner> expectancy : FILE_RESULTS.entrySet()) {
				String fileName = expectancy.getKey();
				Winner winner = winnerChecker.getWinner(new GameInfo(fileName));
				Winner expectedWinner = expectancy.getValue();
				System.out.println(fileName+" Winner: "+winner+" ExpectedWinner: "+expectedWinner);
				Assertions.assertThat(winner).isEqualTo(expectedWinner);
			}
		} catch (GameException e) {
			Assertions.fail("Unexpected exception: "+e.getMessage());
		}
	}
}
