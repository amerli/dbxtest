package com.dbxtest.merliandras.service;

import com.dbxtest.merliandras.model.GameInfo;
import org.springframework.stereotype.Component;

/**
 * Decides if the game is won based on the elements on the given row
 */
@Component
public class RowWinChecker implements WinCheckerStrategy {
    @Override
    public boolean isWin(GameInfo gameInfo, int i, int j) {
        Character[][] board = gameInfo.getBoard();
        int necessaryScore = gameInfo.getNecessaryScoreToWin();
        Character player = board[i][j];
        int actualScore = 1;
        // parse row by decreasing the idx
        int idx = 1;
        while (j-idx >= 0 && board[i][j-idx].equals(player) && actualScore != necessaryScore) {
            actualScore++;
            idx++;
        }
        // parse row by increasing the idx
        idx = 1;
        while (j+idx < board[i].length && board[i][j+idx].equals(player) && actualScore != necessaryScore) {
            actualScore++;
            idx++;
        }
        return actualScore == necessaryScore;
    }
}
