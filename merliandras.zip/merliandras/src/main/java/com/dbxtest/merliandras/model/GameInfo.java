package com.dbxtest.merliandras.model;

import com.dbxtest.merliandras.WinnerCheckerApplication;
import com.dbxtest.merliandras.exception.GameException;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created based on an input file which contains the game information.
 * Provides all the known game information
 */
public class GameInfo {
    private Character[][] board;
    private int necessaryScoreToWin;

    /**
     * Reads the game information from a file
     * @param fileName Input file name
     * @throws GameException If there's some problem with the input data
     */
    public GameInfo(String fileName) throws GameException {
        InputStream is = getResourceFileAsInputStream(fileName);
        if (is != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            List<String> lines = reader.lines().toList();
            // at least two lines are expected in the file: board info and winning-score info
            if (lines.size() < 2) {
                throw new GameException("Not enough lines in the file");
            }
            // read the game info from the file
            readBoard(lines);
            readScoreToWin(lines);
        } else {
            throw new GameException("The input file is not found");
        }
    }

    private static InputStream getResourceFileAsInputStream(String fileName) {
        if (!StringUtils.hasLength(fileName)) {
            return null;
        }
        ClassLoader classLoader = WinnerCheckerApplication.class.getClassLoader();
        return classLoader.getResourceAsStream(fileName);
    }

    private void readBoard(List<String> lines) throws GameException {
        board = new Character[lines.size()-1][];
        for (int lineIdx = 0; lineIdx < board.length; lineIdx++) {
            String line = lines.get(lineIdx).toUpperCase();
            // transform the line into an array of chars
            char[] chars = line.toCharArray();
            board[lineIdx] = new Character[chars.length];
            // validate the chars of the line
            for (int charIdx = 0; charIdx < chars.length; charIdx++) {
                Character c = chars[charIdx];
                if (c.equals(' ') || c.equals('X') || c.equals('O')) {
                    board[lineIdx][charIdx] = c;
                } else {
                    throw new GameException("The game board contains the invalid character: "+c);
                }
            }
            // validate the line length
            if (lineIdx > 0 && board[lineIdx-1].length != chars.length) {
                throw new GameException("The input 2D array doesn't have a rectangular shape!");
            }
        }
    }

    private void readScoreToWin(List<String> lines) throws GameException {
        try {
            necessaryScoreToWin = Integer.parseInt(lines.get(lines.size()-1));
        } catch (NumberFormatException e) {
            throw new GameException("Couldn't get the necessary 'score to win' parameter (last line in the file)");
        }
    }

    public Character[][] getBoard() {
        return board;
    }

    public int getNecessaryScoreToWin() {
        return necessaryScoreToWin;
    }
}
