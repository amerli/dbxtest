package com.dbxtest.merliandras.service;

import com.dbxtest.merliandras.model.GameInfo;

/**
 * Decides if the game is won based on the implemented strategy
 */
public interface WinCheckerStrategy {
    /**
     * @return Is the game won by the player on the i,j coordinates?
     */
    boolean isWin(GameInfo gameInfo, int i, int j);
}
