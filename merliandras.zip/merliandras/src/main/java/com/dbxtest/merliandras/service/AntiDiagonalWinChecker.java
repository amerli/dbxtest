package com.dbxtest.merliandras.service;

import com.dbxtest.merliandras.model.GameInfo;
import org.springframework.stereotype.Component;

/**
 * Decides if the game is won based on the elements on the given anti-diagonal
 */
@Component
public class AntiDiagonalWinChecker implements WinCheckerStrategy{
    @Override
    public boolean isWin(GameInfo gameInfo, int i, int j) {
        Character[][] board = gameInfo.getBoard();
        int necessaryScore = gameInfo.getNecessaryScoreToWin();
        Character player = board[i][j];
        int actualScore = 1;
        // parse diagonal by decreasing the row idx and increasing the column idx
        int idx = 1;
        while (i-idx >= 0 && j+idx < board[i].length && board[i-idx][j+idx].equals(player) && actualScore != necessaryScore) {
            actualScore++;
            idx++;
        }
        // parse diagonal by increasing the row idx and decreasing the column idx
        idx = 1;
        while (i+idx < board.length && j-idx >= 0 && board[i+idx][j-idx].equals(player) && actualScore != necessaryScore) {
            actualScore++;
            idx++;
        }
        return actualScore == necessaryScore;
    }
}
