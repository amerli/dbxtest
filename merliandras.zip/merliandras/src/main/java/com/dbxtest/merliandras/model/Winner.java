package com.dbxtest.merliandras.model;

/**
 * Represents information about the winner of a game and some explanation if there's no winner found
 */
public enum Winner {
    PLAYER_1_X("Player1 won (X)"),
    PLAYER_2_O("Player2 won (O)"),
    DRAW("Draw (there's no winner and no empty fields left)"),
    NO_WINNER_YET("There is no winner yet, but there are still some empty fields to play with");

    private final String description;

    Winner(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
