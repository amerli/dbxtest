package com.dbxtest.merliandras.exception;

public class GameException extends Exception {
    public GameException(String s) {
        super(s);
    }
}
