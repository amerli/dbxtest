package com.dbxtest.merliandras;

import com.dbxtest.merliandras.exception.GameException;
import com.dbxtest.merliandras.model.GameInfo;
import com.dbxtest.merliandras.model.Winner;
import com.dbxtest.merliandras.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;
import java.util.Scanner;

@SpringBootApplication
public class WinnerCheckerApplication implements CommandLineRunner {
	@Autowired
	private WinnerChecker winnerChecker;
	@Autowired
	private RowWinChecker rowWinChecker;
	@Autowired
	private ColumnWinChecker columnWinChecker;
	@Autowired
	private DiagonalWinChecker diagonalWinChecker;
	@Autowired
	private AntiDiagonalWinChecker antiDiagonalWinChecker;

	public static void main(String[] args) {
		SpringApplication.run(WinnerCheckerApplication.class, args);
	}

	@Override
	public void run(String... args) {
		// read input file names from the console and output the winner-related information
		// the 'quit' input breaks the cycle
		// maybe setting the strategies can be also customizable in the future (e.g. check only by rows and columns)
		winnerChecker.setWinCheckerStrategies(Arrays.asList(rowWinChecker, columnWinChecker, diagonalWinChecker, antiDiagonalWinChecker));
		while (true) {
			System.out.println();
			System.out.println("Please indicate which file should be used from the resources folder (enter quit to quit):");
			Scanner scanner = new Scanner(System.in);
			String fileName = scanner.nextLine();
			if (fileName.equals("quit")) {
				break;
			}
			try {
				Winner winner = winnerChecker.getWinner(new GameInfo(fileName));
				System.out.println("Information about the winner: " + winner.getDescription());
			} catch (GameException e) {
				System.out.println("An exception occurred during the processing: " + e.getMessage());
			}
		}
	}
}
