package com.dbxtest.merliandras.service;

import com.dbxtest.merliandras.model.GameInfo;
import com.dbxtest.merliandras.model.Winner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class WinnerChecker {
    private List<WinCheckerStrategy> winCheckerStrategies;

    /**
     * @param gameInfo The known game information
     * @return Winner-related information based on the input
     */
    public Winner getWinner(GameInfo gameInfo) {
        // helps to decide weather we have an ongoing game or not
        boolean emptiesArePresent = false;
        Character[][] board = gameInfo.getBoard();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                emptiesArePresent = emptiesArePresent || board[i][j].equals(' ');
                // try to find out if the i, j coordinate is a winning position
                Character winner = getWinner(gameInfo, i, j);
                if (winner != null) {
                    // stop as soon as a winner is found
                    return winner.equals('X') ? Winner.PLAYER_1_X : Winner.PLAYER_2_O;
                }
            }
        }
        // couldn't find a winner: maybe the game is still ongoing or the result is a draw
        return emptiesArePresent ? Winner.NO_WINNER_YET : Winner.DRAW;
    }

    /**
     * @return Does X or Y win on the given i and j coordinates?
     */
    private Character getWinner(GameInfo gameInfo, int i, int j) {
        Character[][] board = gameInfo.getBoard();
        Character player = board[i][j];
        if (!player.equals(' ')) {
            if (winCheckerStrategies.stream().anyMatch(s -> s.isWin(gameInfo, i, j))) {
                // multiple strategies were applied to check the win condition
                // and it was found out that the person playing the i,j coordinates has won
                return player;
            }
        }
        return null;
    }

    /**
     * @param winCheckerStrategies The strategies which are intended to check the winning condition
     */
    public void setWinCheckerStrategies(List<WinCheckerStrategy> winCheckerStrategies) {
        this.winCheckerStrategies = winCheckerStrategies;
    }
}
